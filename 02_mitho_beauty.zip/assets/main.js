(function ($) {
  "use strict";
  jQuery(document).ready(function() {
    document.onkeydown = function(e) {
      if(event.keyCode == 123) {
        return false;
      }
      if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
        return false;
      }
      if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
        return false;
      }
      if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
        return false;
      }
      if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
        return false;
      }
    }

    // menu toggler js
    $("button.navbar-toggler").on('click', function() {
      $(".main-menu-area").addClass("active");
      $(".mm-fullscreen-bg").addClass("active");
      $("body").addClass("hidden");
    });
    $(".close-box").on('click', function() {
      $(".main-menu-area").removeClass("active");
      $(".mm-fullscreen-bg").removeClass("active");
      $("body").removeClass("hidden");
    });

    // filter button js
    $("button.filter-button").on('click', function() {
      $(".filter-sidebar").addClass("active");
      $(".mm-fullscreen-bg").addClass("active");
    });
    $("button.close-filter-sidebar").on('click', function() {
      $(".filter-sidebar").removeClass("active");
      $(".mm-fullscreen-bg").removeClass("active");
    });

    // body background color js
    $(".mm-fullscreen-bg").on('click', function() {
      $(".main-menu-area").removeClass("active");
      $(".filter-sidebar").removeClass("active");
      $(".mm-fullscreen-bg").removeClass("active");
      $("body").removeClass("hidden");
    });

    // product-img full-view & magnific popup
    $('.full-view, .zoom').on('click', function() {
      $('.product_img_top').magnificPopup({
        delegate: 'a',
        type:'image',
        showCloseBtn: true,
        closeBtnInside: false,
        midClick: true,
        tLoading: 'Loading image #%curr%...',
        mainClass: 'mfp-img-mobile',
        gallery: {
          enabled: true,
          navigateByImgClick: true,
          preload: [0,1]
        }
      }).magnificPopup('open');
    });
  });
})(jQuery);